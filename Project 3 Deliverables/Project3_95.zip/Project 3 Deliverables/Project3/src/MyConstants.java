class MyConstants {


    public static final String SITE_KEY ="6LfkZSEUAAAAAJ1eB5CQ1XWc-FrXt59rM-gDOIZa";

    public static final String SECRET_KEY ="6LfkZSEUAAAAADU_6tygt39WejDCbL-xnWJi4Lzt";

}

