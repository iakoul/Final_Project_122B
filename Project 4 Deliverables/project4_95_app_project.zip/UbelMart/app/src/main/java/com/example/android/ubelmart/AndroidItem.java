package com.example.android.ubelmart;

public class AndroidItem {
    private String name;

    public AndroidItem(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}